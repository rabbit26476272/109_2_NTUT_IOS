
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ACButton: UIButton!
    @IBOutlet weak var equalButton: UIButton!
    @IBOutlet var operatorButton: [UIButton]!
    @IBOutlet var numberButton: [UIButton]!
    @IBOutlet weak var currentDisplayLabel: UILabel!
    @IBOutlet weak var processDisplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ACButton.layer.cornerRadius = 45
        equalButton.layer.cornerRadius = 45
        
        for i in 0 ... numberButton.indices.count - 1{
            numberButton[i].layer.cornerRadius = 45
        }
        for i in 0 ... operatorButton.indices.count - 1{
            operatorButton[i].layer.cornerRadius = 45
        }
    }
    var displayValue = "0" {
        didSet {
            currentDisplayLabel.text = "\(displayValue)"
        }
    }
    var displayProcess = "" {
        didSet {
            processDisplayLabel.text = "\(displayProcess)"
        }
    }
    var hasAction = false
    var hasNumber = false
    var hasDot = false
    var hasOperator = false
    var hasTouchEqual = false
    var IsOperator = 0
    var operatorChoices = ["÷","×","-","+"]
    lazy var calculator = Calculator()

    @IBAction func touchACButton(_ sender: UIButton) {
        print("AC")
        ACButton.setTitle("AC", for: .normal)
        clearView()
    }
    @IBAction func touchOperatorButton(_ sender: UIButton) {
        hasDot = false
        hasAction = true
        if(hasTouchEqual) {
            clearView()
        }
        if(!hasOperator) {
            if(!hasNumber) {
                calculator.modifyOperator(tag:sender.tag)
                IsOperator = sender.tag
            }else {
                displayProcess = displayProcess + operatorChoices[sender.tag - 14]
                calculator.addNumber()
                calculator.addOperator(tag:sender.tag)
                IsOperator = sender.tag
                hasOperator = true
                hasNumber = false
            }
        }else {
            displayProcess = displayProcess.prefix(displayProcess.count - 1) + operatorChoices[sender.tag - 14]
            calculator.modifyOperator(tag:sender.tag)
            IsOperator = sender.tag
        }
    }
    @IBAction func touchNumberButton(_ sender: UIButton) {
        ACButton.setTitle("C", for: .normal)
        if(hasTouchEqual) {
           clearView()
        }
        if(!hasAction && sender.tag != 0) {
            hasAction = true
        }
        if(hasAction) {
            if(!hasNumber) {
                if(sender.tag == 10) {
                    calculator.updateNumber(tag:sender.tag)
                    displayValue = displayValue + "."
                    displayProcess = displayProcess +  "."
                    hasDot = true
                }else {
                    calculator.updateNumber(tag:sender.tag)
                    displayValue = String(sender.tag)
                    displayProcess = displayProcess + String(sender.tag)
                    
                }
                hasNumber = true
                hasOperator = false
                
            }else {
                if(sender.tag == 10) {
                    if(!hasDot) {
                        displayValue = displayValue + "."
                        displayProcess = displayProcess + "."
                        calculator.updateNumber(tag:sender.tag)
                        hasDot = true
                    }
                }else {
                    calculator.updateNumber(tag:sender.tag)
                    displayValue = displayValue + String(sender.tag)
                    displayProcess = displayProcess + String(sender.tag)
                }
               
                hasNumber = true
                hasOperator = false
            }
            //calculator.displayNumbers()
        }
    }
    @IBAction func touchEqualButton(_ sender: UIButton) {
        calculator.addNumber()
        //calculator.displayProcess()
        displayProcess = displayProcess + "="
        hasTouchEqual = true
        displayResult()
    }
    func toInt(character:Character)->Int {
        return (Int(String(character) ?? "0") ?? 0)
    }
    func displayResult() {
        let result = calculator.calculate()
        if(String(result) == "inf") {
            displayValue = "0" 
        }else{
            let judgment = Int(result)
            displayValue = String(result)
            print("result = " + "\(result)")
            
            if(result == Double(judgment)) {
                displayValue = displayValue.prefix(displayValue.count - 2) + ""
            }else {
                var dot = 0
                var register_String = String(result)
                
                for i in stride(from: 0, to: register_String.count, by:1) {
                    var index = register_String.index(register_String.startIndex, offsetBy: i)
                    if(register_String[index] == ".") {
                        dot = i
                        break;
                    }
                }
                if(register_String.count - dot - 1 >= 8) {
                    
                    displayValue = String(judgment) + "."
                    print(result - Double(judgment))
                    
                    var register_Double = result - Double(judgment)
                    var register_String = String(register_Double)
                    var hasTrouble = false
                    var index = register_String.index(register_String.startIndex, offsetBy: 0)
                    register_String.remove(at: index)
                    register_String.remove(at: index)
                    print(register_String)
                    
                    for i in stride(from: 0, to: register_String.count - 1, by:1) {
                        index = register_String.index(register_String.startIndex, offsetBy: i)
                        var count = 0
                        for j in stride(from: i + 1, to:register_String.count - 1, by:1) {
                            
                            let iden = register_String.index(register_String.startIndex, offsetBy: j)
                            //print("i = " + "\(i)"+","+"\(register_String[index])"+","+"j = "+"\(j)"+","+"\(register_String[iden])")
                            if(register_String[index] == register_String[iden]) {
                                count += 1
                            }else{
                                break;
                            }
                        }
                        if(count >= 5) {
                            print("i = " + "\(i)")
                            hasTrouble = true
                            var base = 1.0
                            for _ in 0 ... i - 1 {
                                base *= 10.0
                            }
                            var register_Int = Int((register_Double) * base)
                            if(toInt(character: register_String[index]) >= 5) {
                                register_Int += 1
                            }
                            print(String(register_Int))
                            displayValue = displayValue + String(register_Int)
                            break;
                        }
                    }
                    
                    if(!hasTrouble) {
                        var base = 1.0
                        for _ in 0 ... 7 {
                            base *= 10.0
                        }
                        var register_Int = Int((register_Double) * base)
                        index = register_String.index(register_String.startIndex, offsetBy: 8)
                        if(toInt(character: register_String[index]) >= 5) {
                            register_Int += 1
                        }
                        displayValue = displayValue + String(register_Int)
                    }
                }
            }
        }
    }
    func clearView() {
        calculator.clearCalculator()
        displayValue = "0"
        displayProcess = ""
        hasAction = false
        hasNumber = false
        hasDot = false
        hasOperator = false
        hasTouchEqual = false
    }
    @IBAction func alert(_ sender: Any) {
        let alert = UIAlertController(title: "提醒", message: "此功能未完成", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "確定", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

