import Foundation
import UIKit

class Calculator {
    var number = [Int]()
    var numbers = [Double]()
    var operatorion = [Int]()
    var operatorChoices = ["÷","×","-","+"]
    init() {
        number.append(0)
        numbers.append(0)
        operatorion.append(0)
    }
    func updateNumber(tag:Int) {
        number.append(tag)
    }
    func addNumber() {
        numbers.append(0)
        var dot = number.count
        for i in 0 ... number.count - 1 {
             if(number[i] == 10) {
                 dot = i
                 break;
             }
        }
        for i in 0 ... dot - 1 {
            var base = 1.0
            for _ in stride(from: i, to: dot - 1, by: 1) {
                base *= 10.0
            }
            numbers[numbers.count - 1] += (Double(number[i]) * base)
        }
        if(dot != number.count) {
            for i in dot + 1 ... number.count - 1 {
                var power = 1.0
                for _ in stride(from: dot , to: i, by: 1) {
                    power *= 0.1
                }
                numbers[numbers.count - 1] += (Double(number[i]) * power)
            }
        }
        
        //print(numbers[numbers.count - 1])
        number.removeAll()
        number.append(0)
        
    }
    func addOperator(tag:Int) {
        operatorion.append(0)
        operatorion[operatorion.count - 1] = tag
    }
    func modifyOperator(tag:Int) {
        operatorion[operatorion.count - 1] = tag
    }
    func calculate()->Double {
        var count = 0
        while(count < operatorion.count) {
            switch operatorion[count] {
                case 14:
                    numbers[count] = numbers[count] / numbers[count + 1]
                    operatorion.remove(at: count)
                    numbers.remove(at: count + 1)
                    count = 0
                    break;
                case 15:
                    numbers[count] = numbers[count] * numbers[count + 1]
                    operatorion.remove(at: count)
                    numbers.remove(at: count + 1)
                    count = 0
                    break;
                default:
                    break;
            }
            count += 1
        }
        while(operatorion.count >= 1) {
            switch operatorion[0] {
                case 16:
                    numbers[1] = numbers[0] - numbers[1]
                    break;
                case 17:
                    numbers[1] = numbers[0] + numbers[1]
                    break;
                default:
                    break;
            }
            operatorion.remove(at: 0)
            numbers.remove(at: 0)
        }
        return numbers[0]
    }
    func clearCalculator() {
        number.removeAll()
        numbers.removeAll()
        operatorion.removeAll()
        number.append(0)
        numbers.append(0)
        operatorion.append(0)
    }
}
